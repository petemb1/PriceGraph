
.. include:: ../../README.rst
    :start-after: $> cd docs; make clean html latexpdf