
License
=======

.. literalinclude:: ../../LICENSE.txt