
.. include:: ../../README.rst
    :start-after: Not implemented yet.
    :end-before: Development
