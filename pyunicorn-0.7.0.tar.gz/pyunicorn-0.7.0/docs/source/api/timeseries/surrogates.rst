
timeseries.surrogates
=====================

.. automodule:: pyunicorn.timeseries.surrogates
    :synopsis: spatially embedded networks, multivariate data,
               time series surrogates
    :members:
    :private-members:
    :special-members:
    :show-inheritance:
