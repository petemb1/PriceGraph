
core.spatial_network
====================

.. automodule:: pyunicorn.core.spatial_network
    :synopsis: spatially embedded complex networks, multivariate data,
               time series surrogates
    :members:
    :private-members:
    :special-members:
    :show-inheritance:
