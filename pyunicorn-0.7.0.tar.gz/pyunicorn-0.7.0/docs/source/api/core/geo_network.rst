
core.geo_network
================

.. automodule:: pyunicorn.core.geo_network
    :synopsis: spatially embedded complex networks, multivariate data,
               time series surrogates
    :members:
    :private-members:
    :special-members:
    :show-inheritance:
