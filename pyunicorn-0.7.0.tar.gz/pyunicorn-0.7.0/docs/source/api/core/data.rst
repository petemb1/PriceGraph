
core.data
=========

.. automodule:: pyunicorn.core.data
    :synopsis: spatially embedded complex networks, multivariate data,
               time series surrogates
    :members:
    :private-members:
    :special-members:
    :show-inheritance:
