
core.netcdf_dictionary
======================

.. automodule:: pyunicorn.core.netcdf_dictionary
    :synopsis: NetCDF <-> Python dictionary, NetCDF4 compression
    :members:
    :private-members:
    :special-members:
    :show-inheritance:
