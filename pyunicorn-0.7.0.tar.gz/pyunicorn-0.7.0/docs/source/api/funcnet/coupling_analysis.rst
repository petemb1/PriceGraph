
funcnet.coupling_analysis
=========================

.. automodule:: pyunicorn.funcnet.coupling_analysis
    :synopsis: spatially embedded complex networks, multivariate data, time
               series surrogates
    :members:
    :private-members:
    :special-members:
    :show-inheritance:
