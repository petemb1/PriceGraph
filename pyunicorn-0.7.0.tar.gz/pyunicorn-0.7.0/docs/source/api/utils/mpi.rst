
utils.mpi
=========

.. automodule:: pyunicorn.utils.mpi
    :synopsis: parallelization using mpi4py
    :members:
    :private-members:
    :special-members:
    :show-inheritance:
