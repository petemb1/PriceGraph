
climate.map_plot
=================

.. automodule:: pyunicorn.climate.map_plot
    :synopsis: spatially embedded complex networks, multivariate data,
               time series surrogates
    :members:
    :private-members:
    :special-members:
    :show-inheritance:
