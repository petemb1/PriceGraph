
eventseries.event_series
========================

.. automodule:: pyunicorn.eventseries.event_series
    :synopsis: event synchronization, event coincidence analysis
    :members:
    :private-members:
    :special-members:
    :show-inheritance:
